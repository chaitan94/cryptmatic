<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');

$route['default_controller'] = 'Home';

$route['rules'] = 'Rules';
$route['level'] = 'Level';
$route['aboutus'] = 'Aboutus';
$route['register'] = 'Register';
$route['profile'] = 'Home';
$route['login'] = 'Login';
$route['logout'] = 'Logout';

$route['404_override'] = '';