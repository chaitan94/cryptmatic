<!DOCTYPE html>
<html>
<head>
	<title>Cryptmatic</title>
	<link rel="stylesheet" href="/assets/css/base.css">
	<link rel="stylesheet" href="/assets/css/page.css">
</head>
<body>
<?php include '/assets/header.php'; ?>
<div class="cont">
<div class="card">
<h1>NOUS:</h1>
<ul>
	<li>je</li>
	<li>vous</li>
	<li>nous</li>
	<li>il</li>
	<li>elle</li>
</ul>
</div>
</div>
</body>
</html>