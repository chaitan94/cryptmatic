<!DOCTYPE html>
<html>
<head>
	<title>Cryptmatic</title>
	<link rel="stylesheet" href="/assets/css/base.css">
	<link rel="stylesheet" href="/assets/css/page.css">
</head>
<body>
<?php include '/assets/header.php'; ?>
<div class="cont">
<div class="card">
<h1>Cryptmatic!</h1>
<br>
IIT-I's online treasure hunt.
<br>
<br>
Register yourslef and start hunting!
<br>
<br>
<br>
<br>
Like Fluxus:<br>
<iframe src="//www.facebook.com/plugins/like.php?href=https%3A%2F%2Fwww.facebook.com%2Ffluxus.iiti&amp;width=450&amp;height=80&amp;colorscheme=light&amp;layout=standard&amp;action=like&amp;show_faces=true&amp;send=true" scrolling="no" frameborder="0" style="border:none; overflow:hidden; width:450px; height:80px;" allowTransparency="true"></iframe>
</div>
</div>
</body>
</html>