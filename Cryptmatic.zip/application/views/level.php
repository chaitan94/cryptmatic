<!DOCTYPE html>
<html>
<head>
	<title>Cryptmatic</title>
	<link rel="stylesheet" href="/assets/css/base.css">
	<link rel="stylesheet" href="/assets/css/page.css">
</head>
<body>
<?php include '/assets/header.php'; ?>
<div class="cont">
<div class="card">
<h1>Question No. <?= $lvl ?> goes here (If any):</h1>
Images go here<br>
Images go here<br>
Images go here<br>
Images go here<br>
Images go here<br>
Images go here<br>
Images go here<br>
Images go here<br>
Images go here<br>
Images go here<br>
Images go here<br>
Images go here<br>
Images go here<br>
Images go here<br>
Images go here<br>
Images go here<br>
Answer in the url (change it to /level/answer)
</div>
</div>
</body>
</html>