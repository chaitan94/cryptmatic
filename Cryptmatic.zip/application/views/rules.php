<!DOCTYPE html>
<html>
<head>
	<title>Cryptmatic</title>
	<link rel="stylesheet" href="/assets/css/base.css">
	<link rel="stylesheet" href="/assets/css/page.css">
</head>
<body>
<?php include '/assets/header.php'; ?>
<div class="cont">
<div class="card">
<h1>Rules:</h1>
<ul>
	<li>No capital letters in URLs</li>
	<li>No spaces</li>
	<li>Numbers should only be written in words</li>
</ul>
</div>
</div>
</body>
</html>